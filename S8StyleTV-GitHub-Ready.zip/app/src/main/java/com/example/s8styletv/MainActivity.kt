package com.example.s8styletv

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.ui.viewinterop.AndroidView

private val Bg = Color(0xFF080B12)
private val Panel = Color(0xFF111827)
private val Accent = Color(0xFF2F80ED)

private data class Channel(val name: String, val group: String, val streamUrl: String, val favorite: Boolean = false)

private val sampleChannels = listOf(
    Channel("Demo News", "News", "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4"),
    Channel("Demo Sports", "Sports", "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4"),
    Channel("Demo Family", "Family", "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4"),
    Channel("Demo Music", "Music", "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { S8StyleTVApp() }
    }
}

@Composable
fun S8StyleTVApp() {
    var selected by remember { mutableStateOf("Home") }
    var playing by remember { mutableStateOf<Channel?>(null) }
    var channels by remember { mutableStateOf(sampleChannels) }
    val nav = listOf("Home", "Live TV", "Guide", "Movies", "Favorites", "Settings")

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Accent)) {
        if (playing != null) {
            PlayerScreen(channel = playing!!, onBack = { playing = null })
        } else {
            Column(Modifier.fillMaxSize().background(Bg).padding(28.dp)) {
                Header()
                Spacer(Modifier.height(20.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(nav) { item -> NavButton(item, item == selected) { selected = item } }
                }
                Spacer(Modifier.height(24.dp))
                when (selected) {
                    "Home" -> HomeScreen(channels) { playing = it }
                    "Live TV" -> LiveTVScreen(channels, onPlay = { playing = it }, onToggleFavorite = { channel ->
                        channels = channels.map { if (it.name == channel.name) it.copy(favorite = !it.favorite) else it }
                    })
                    "Guide" -> GuideScreen(channels)
                    "Movies" -> ContentScreen("Movies", listOf("Featured Movies", "Action", "Comedy", "Drama", "Family"))
                    "Favorites" -> LiveTVScreen(channels.filter { it.favorite }, onPlay = { playing = it }, onToggleFavorite = { channel ->
                        channels = channels.map { if (it.name == channel.name) it.copy(favorite = !it.favorite) else it }
                    })
                    "Settings" -> SettingsScreen()
                }
            }
        }
    }
}

@Composable private fun Header() {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Text("S8", color = Accent, fontSize = 34.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.width(8.dp))
        Text("STYLE TV", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.weight(1f))
        Text("TV", color = Color.LightGray, fontSize = 18.sp)
    }
}

@Composable private fun NavButton(label: String, selected: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Button(onClick = onClick, modifier = Modifier.onFocusChanged { focused = it.isFocused }.focusable(), colors = ButtonDefaults.buttonColors(containerColor = if (selected || focused) Accent else Panel), shape = RoundedCornerShape(10.dp)) { Text(label) }
}

@Composable private fun HomeScreen(channels: List<Channel>, onPlay: (Channel) -> Unit) {
    Column {
        Text("Welcome", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("Choose something to watch", color = Color.Gray, fontSize = 17.sp)
        Spacer(Modifier.height(18.dp))
        Text("Live Channels", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) { items(channels) { ChannelTile(it, onPlay) } }
        Spacer(Modifier.height(20.dp))
        Section("Continue Watching", listOf("News Replay", "Movie Night", "Sports Replay"))
    }
}

@Composable private fun LiveTVScreen(channels: List<Channel>, onPlay: (Channel) -> Unit, onToggleFavorite: (Channel) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Text("Live TV", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("Select a channel to start playback", color = Color.Gray, fontSize = 17.sp)
        Spacer(Modifier.height(14.dp))
        if (channels.isEmpty()) Text("No favorite channels yet.", color = Color.Gray, fontSize = 18.sp)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(channels) { channel ->
                ChannelRow(channel, onPlay, onToggleFavorite)
            }
        }
    }
}

@Composable private fun ChannelRow(channel: Channel, onPlay: (Channel) -> Unit, onToggleFavorite: (Channel) -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().height(72.dp).background(if (focused) Accent else Panel, RoundedCornerShape(10.dp)).onFocusChanged { focused = it.isFocused }.focusable().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(channel.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(channel.group, color = Color.LightGray, fontSize = 14.sp)
        }
        TextButton(onClick = { onToggleFavorite(channel) }) { Text(if (channel.favorite) "★" else "☆", fontSize = 24.sp) }
        Button(onClick = { onPlay(channel) }) { Text("Watch") }
    }
}

@Composable private fun ChannelTile(channel: Channel, onPlay: (Channel) -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Card(onClick = { onPlay(channel) }, modifier = Modifier.width(220.dp).height(120.dp).onFocusChanged { focused = it.isFocused }, colors = CardDefaults.cardColors(containerColor = if (focused) Accent else Panel), shape = RoundedCornerShape(12.dp)) {
        Box(Modifier.fillMaxSize().padding(14.dp), contentAlignment = Alignment.BottomStart) { Text(channel.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp) }
    }
}

@Composable private fun PlayerScreen(channel: Channel, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val player = remember(channel.streamUrl) { ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(Uri.parse(channel.streamUrl))); prepare(); playWhenReady = true } }
    DisposableEffect(player) { onDispose { player.release() } }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = true } }, modifier = Modifier.fillMaxSize())
        Button(onClick = onBack, modifier = Modifier.padding(24.dp).align(Alignment.TopStart)) { Text("Back") }
        Text(channel.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(24.dp).align(Alignment.BottomStart))
    }
}

@Composable private fun ContentScreen(title: String, items: List<String>) { Column { Text(title, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(18.dp)); Section("", items) } }

@Composable private fun Section(title: String, items: List<String>) {
    if (title.isNotBlank()) Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
    Spacer(Modifier.height(8.dp))
    LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) { items(items) { CardTile(it) } }
    Spacer(Modifier.height(20.dp))
}

@Composable private fun CardTile(label: String) {
    var focused by remember { mutableStateOf(false) }
    Card(onClick = {}, modifier = Modifier.width(190.dp).height(108.dp).onFocusChanged { focused = it.isFocused }, colors = CardDefaults.cardColors(containerColor = if (focused) Accent else Panel), shape = RoundedCornerShape(12.dp)) {
        Box(Modifier.fillMaxSize().padding(14.dp), contentAlignment = Alignment.BottomStart) { Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp) }
    }
}

@Composable private fun GuideScreen(channels: List<Channel>) {
    Column {
        Text("Program Guide", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        channels.forEachIndexed { index, channel ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp).background(Panel, RoundedCornerShape(8.dp)).padding(16.dp)) {
                Text(channel.name, Modifier.width(190.dp), Color.White, fontWeight = FontWeight.Bold)
                Text("${9 + index}:00  Now Playing", color = Color.LightGray)
            }
        }
    }
}

@Composable private fun SettingsScreen() {
    Column {
        Text("Settings", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        listOf("Playlist / M3U", "EPG Guide", "Playback", "Network", "Parental Controls", "About").forEach { item ->
            Card(onClick = {}, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Panel)) { Text(item, color = Color.White, fontSize = 18.sp, modifier = Modifier.padding(18.dp)) }
        }
    }
}
